import { useEffect, useState } from "react"

export function Accordion({children, data}){
    const [search,  setSearch] = useState("")
    const [dataView,  setDataView] = useState([])

    function getFilteretedData(){
        const newData = data.slice(0, 10) 
        const sortData = newData.sort((a, b) => {
                const titleA = a.name.toUpperCase();
                const titleB = b.name.toUpperCase();
                if (titleA < titleB) {return -1;}
                if (titleA > titleB) {return 1;}
                return 0;
        }).filter((product) => product.name.find(search) != 0)
        setDataView(sortData)
    }

    useEffect(()=>{
        getFilteretedData()
    }, [])

    return <div>
        {search}
        <input type="text" 
            value={search}
            onChange={(e) => {
                setSearch(e.target.value)
                getFilteretedData()
            }}
        ></input>
        {dataView.length > 0 ? 
            <ol>
            {dataView.map((item, idx) => (
                <li key={item.id}>{item.name}</li> 
            ))}
            </ol>
        : <div>no data</div>
        }
        </div>
}

