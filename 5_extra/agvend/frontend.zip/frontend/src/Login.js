import { NavLink } from "react-router";
import axios from "axios";
import { useState } from "react";
import { useSelector, useDispatch } from 'react-redux'
import { decrement, increment } from './store'

export default function Login({children}){

    const dispatch = useDispatch()
    const count = useSelector((state) => state.counter.value)
    const [data1, setData1] = useState({})

    function getData(){

        axios
        .get("https://jsonplaceholder.typicode.com/posts", {
            params: {
            postId: 5,
            },
        })
        .then((response) => {
            console.log(response.data);
            setData1(response)
        })
        .catch((error) => {
            console.error(error);
        })
        .finally(() => {
            console.log("Request completed");
        });
    }

  return <div>Login {children} page
  
  <NavLink
          className="App-link"
          to="/"
        >
          home
        </NavLink>

        <button className="btn btn-lg btn-warning" onClick={getData}>getData</button>


<hr/>


{data1 && data1.data ? <div className="row">

{data1.data.map((item, idx) => (
<div class="card col-lg-4">
  <div class="card-body">
    <h5 class="card-title">{item.title}</h5>
    <p class="card-text">{item.body}</p>
    <a href="#" class="btn btn-danger p-3">Go somewhere</a>
  </div>
</div>
))}
</div> : <div>not data</div>}


<div>
        <button
          aria-label="Increment value"
          onClick={() => dispatch(increment())}
        >
          Increment
        </button>
        <span>{count}</span>
        <button
          aria-label="Decrement value"
          onClick={() => dispatch(decrement())}
        >
          Decrement
        </button>
      </div>



  </div>
}
