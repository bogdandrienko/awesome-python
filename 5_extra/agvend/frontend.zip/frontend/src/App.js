import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import { NavLink } from "react-router";
import { useSelector, useDispatch } from 'react-redux'

function Login({children}){
  return <div>Login {children} page</div>
}

function ButtonCustom1({title, body}){
  return <div>
    <strong>{title}</strong>
    <p>{body}</p>
  </div>
}

function App() {
    const count = useSelector((state) => state.counter.value)
  const [data1, setData1] = useState({value:13})
  const value = 12
  function changeValue(val){
    console.log(val)
    setData1({value: val})
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit {count} <code>src/App.js</code> and save to reload.
        </p>
        <NavLink
          className="App-link"
          to="/login"
        >
          Learn React {value} | {data1.value}
        </NavLink>
        <ButtonCustom1 title={"tit"} body={"bod"}></ButtonCustom1>
        <button  onClick={()=> changeValue(22)}>change</button>
      </header>

      <Login>child</Login>
    </div>
  );
}

export default App;
